clc,clear
load data1.txt  %把原始数据保存在纯文本文件data1.txt中
data1(end,:)=[];m=size(data1,2);
x0=mean(data1,2);
x1=cumsum(x0)
alpha=0.4;n=length(x0);
z1=alpha*x1(2:n)+(1-alpha)*x1(1:n-1)
Y=x0(2:n);B=[-z1,ones(n-1,1)];
ab=B\Y
k=6;
x7hat=(x0(1)-ab(2)/ab(1))*(exp(-ab(1)*k)-exp(-ab(1)*(k-1)))
z=m*x7hat
u=sum(data1)/sum(sum(data1))
v=z*u